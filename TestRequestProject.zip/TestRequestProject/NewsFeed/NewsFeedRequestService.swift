//
//  NewsFeedRequestService.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 12.04.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import Foundation
import Alamofire
import Realm
import RealmSwift

class NewsFeedRequestService {
    
    fileprivate let baseUrl = "https://api.vk.com"
    fileprivate let client_id = "6197760"
    fileprivate let path = "/method/newsfeed.get"
    fileprivate let version = "5.8"
    
    
     func downloadNewsData(completion: @escaping ([NewsPost]) -> ()) {
        
        let parameters: Parameters = [ "access_token" : UserRequestService.token,
                                       "user_id"      :  UserRequestService.userId,
                                       "filters"      :  "post",
                                       "return_banned":  "0",
                                       "start_time"   :  "",
                                       "end_time"     :  "",
                                       "source_ids"   :  "friends, groups, pages",
                                       "count"        :  "20",
                                       "fields"       :  "",
                                       "version"      :  version,
                                       "name_case"    :  "nom",
                                                                                         ]
        
        let url = baseUrl + path
        
        request(url, method: .get, parameters: parameters).responseJSON { responseJSON in
            
           
                
            
                var news = [NewsPost]()
                let data = responseJSON.value as! [String: Any]
                let dict = data["response"] as! [String: Any]
                let arrayItems = dict["items"] as! [Any]
                
                for value in arrayItems {
                    let item = value as! [String:Any]
                    let sourceID = item["source_id"] as! Int
                    let textOfPost = item["text"] as? String ?? ""
                    var photoID = ""
                    var nameID = ""
                    let photoOfPost = PhotoOfPost()
                    let linkOfPost = LinkOfPost()
                    let items = Item()
                    var typeOfAttachment = TypeOfAttachment.none
                    if item["attachment"] != nil {
                        let attachment = item["attachment"] as! [String:Any]
                        let typeOfAttachmentJSON = attachment["type"] as! String
                        
                        switch typeOfAttachmentJSON {
                        case "photo" :
                            typeOfAttachment = .photo
                            let photoAttachment = attachment["photo"] as! [String:Any]
                            photoOfPost.urlOfImage = photoAttachment["src_big"] as! String
                            photoOfPost.width = photoAttachment["width"] as! Int
                            photoOfPost.height = photoAttachment["height"] as! Int
                        case "link" :
                            typeOfAttachment = .link
                            let linkAttachment = attachment["link"] as! [String:Any]
                            linkOfPost.urlOfLink = linkAttachment["url"] as! String
                            linkOfPost.title = linkAttachment["title"] as! String
                            if linkAttachment["image_big"] != nil {
                                linkOfPost.image = (linkAttachment["image_big"] as! String)
                            } else if linkAttachment["image_src"] != nil {
                                linkOfPost.image = (linkAttachment["image_src"] as! String)
                            } else { linkOfPost.image = "" }
                        case "video" :
                            typeOfAttachment = .video
                            let videoAttachment = attachment["video"] as! [String:Any]
                            photoOfPost.urlOfImage = videoAttachment["image_big"] as! String
                        case "audio" :
                            typeOfAttachment = .audio
                        case "poll":
                            typeOfAttachment = .poll
                        default: break
                        }
                    } else {
                        typeOfAttachment = .none
                    }
                    //FIXME:
                    if item["photos"] != nil {
                        let arrayOfPhotos = item["photos"] as! [Any]
                        let photoDescribe = arrayOfPhotos[1] as! [String: Any]
                        photoOfPost.urlOfImage = photoDescribe["src_big"] as! String
                        photoOfPost.width = photoDescribe["width"] as! Int
                        photoOfPost.height = photoDescribe["height"] as! Int
                    }
                    
                    if item["likes"] != nil {
                        let likesDescription = item["likes"] as! [String:Any]
                        items.likes = String(likesDescription["count"] as! Int)
                        print("Likes for post", items.likes)
                    }
                    if item["comments"] != nil {
                        let commentsDescription = item["comments"] as! [String:Any]
                        items.comments = String(commentsDescription["count"] as! Int)
                    }
                    if item["reposts"] != nil {
                        let repostsDescription = item["reposts"] as! [String:Any]
                        items.reposts = String(repostsDescription["count"] as! Int)
                        print("Reposts for Post", items.reposts)
                    }
                    if sourceID > 0 {
                        let arrayOfProfiles = dict["profiles"] as! [Any]
                        for value in arrayOfProfiles {
                            let profile = value as! [String:Any]
                            if sourceID == profile["uid"] as! Int {
                                photoID = profile["photo"] as! String
                                nameID = profile["first_name"] as! String + " " + (profile["last_name"] as! String)
                            }
                        }
                    } else {
                        let arrayOfGroups = dict["groups"] as! [Any]
                        for value in arrayOfGroups {
                            let group = value as! [String:Any]
                            if -sourceID == group["gid"] as! Int {
                                photoID = group["photo"] as! String
                                nameID = group["name"] as! String
                            }
                        }

                    }
                   news.append(NewsPost(photoID: photoID, nameID: nameID, textOfPost: textOfPost, typeOfAttachment: typeOfAttachment, photoOfPost: photoOfPost, linkOfPost: linkOfPost, items: items))
                    //print(news)
            }
            completion(news)
                
                
    }
    
    
    }
    
    
    
    
}
