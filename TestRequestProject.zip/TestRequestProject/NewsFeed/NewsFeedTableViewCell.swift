//
//  NewsFeedTableViewCell.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 12.04.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import UIKit

class NewsFeedTableViewCell: UITableViewCell {

    
    @IBOutlet weak var NameID: UILabel!
    
    @IBOutlet weak var photoID: UIImageView!
    
    
    @IBOutlet weak var PhotoOfPost: UIImageView!
    
    @IBOutlet weak var TextOfPost: UITextView!
    
    
    @IBOutlet weak var LikesLabel: UILabel!
    
    @IBOutlet weak var LikesCount: UILabel!
    
    @IBOutlet weak var RepostsLabel: UILabel!
    
    @IBOutlet weak var RepostsCount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
