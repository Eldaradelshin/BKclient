//
//  NewsFeedTableViewController.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 12.04.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import UIKit

class NewsFeedTableViewController: UITableViewController {
    
    @IBAction func refreshButton(_ sender: Any) {
        tableView?.reloadData()
        
    }
    
    
     let newsMethods = NewsMethods()
     let newsFeedRequestService = NewsFeedRequestService()
    var news = [NewsPost]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        newsFeedRequestService.downloadNewsData() { [weak self] news in
            self?.news = news
            self?.tableView.reloadData()
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
       
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return news.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let new = news[indexPath.row]
        var dictCell = newsMethods.cellType(new)
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "newsCell", for: indexPath) as! NewsFeedTableViewCell

        
        cell.NameID.text = news[indexPath.row].nameID
        cell.TextOfPost.text = news[indexPath.row].textOfPost
        cell.LikesLabel.text = "Likes:"
        cell.LikesCount.text = news[indexPath.row].items.likes
        cell.RepostsLabel.text = "Reposts:"
        cell.RepostsCount.text = news[indexPath.row].items.reposts
        
        
        
        
        //let urlPhotoOfPost = URL(string: dictCell["imageOfPost"] as! String)
        if let stringPhotoOfPost = dictCell["imageOfPost"] {
            //print("STRINGOFURL:", stringPhotoOfPost)
            if stringPhotoOfPost != "" {
            let urlPhotoOfPost: URL = URL(string: stringPhotoOfPost)!
                let queue = DispatchQueue.global(qos: .utility)
                queue.async {
                    if let dataPhotoOfPost = try? Data(contentsOf: urlPhotoOfPost) {
                        DispatchQueue.main.async {
                            cell.PhotoOfPost.image = UIImage(data: dataPhotoOfPost)
                        }
                    }
                }
                
            }
        }
        
        
            


        let urlPhotoID: URL = URL(string: news[indexPath.row].photoID)!
        let queue = DispatchQueue.global(qos: .utility)
        queue.async {
            if let dataPhotoID = try? Data(contentsOf: urlPhotoID) {
                DispatchQueue.main.async {
                    cell.photoID.image = UIImage(data: dataPhotoID)
                }
            }
        }
        
        
        return cell
    }
 

}
