//
//  GroupsTableViewController.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 02.02.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import UIKit
import Realm
import RealmSwift


class GroupsTableViewController: UITableViewController {
    
    
    
    @IBAction func groupSearch(_ sender: Any) {
        performSegue(withIdentifier: "groupsSearch", sender: nil)
    }
    
    
    let groupsRequestService = GroupRequestService()
    //var groups = [Group]()
    var groups:Results<Group>!
    var token = RLMNotificationToken()
    

    
    
    func loadGroupData() {
        do {
            let realm = try Realm()
            groups = realm.objects(Group.self)
            token = groups.observe {
                [weak self] changes in
                guard let tableView = self?.tableView else { return }
                switch changes {
                case .initial:
                    tableView.reloadData()
                    break
                case .update(_,let deletions, let insertions, let modifications):
                    tableView.beginUpdates()
                    tableView.insertRows(at: insertions.map({ IndexPath(row: $0, section: 0) }), with: .automatic)
                    tableView.deleteRows(at: deletions.map({ IndexPath(row: $0, section: 0) }), with: .automatic)
                    tableView.reloadRows(at: modifications.map({ IndexPath(row: $0, section: 0) }), with: .automatic)
                    tableView.endUpdates()
                    break
                case .error(let error):
                    fatalError("\(error)")
                }
            }
            
        } catch {
            print(error)
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      groupsRequestService.startFetchingGroups()
      loadGroupData()
    }

    deinit {
        groupsRequestService.stopFetchingGroups()
    }

    
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groups.count
    }


    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "groupCell", for: indexPath) as! GroupsTableViewCell

        cell.groupName.text = groups[indexPath.row].name
        let urlImg: URL = URL(string: groups[indexPath.row].photo)!
        let queue = DispatchQueue.global(qos: .utility)
        queue.async {
            if let dataImg = try? Data(contentsOf: urlImg) {
                DispatchQueue.main.async {
                    cell.groupAvatar.image = UIImage(data: dataImg)
                    
                }
            }
        }

        return cell
    }

    
 }
