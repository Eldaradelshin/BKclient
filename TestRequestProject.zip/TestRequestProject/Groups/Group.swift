//
//  Group.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 31.01.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import Foundation
import RealmSwift

class Group: Object {
    
    @objc dynamic var id : Int = 0
    @objc dynamic var is_admin : Bool = false
    @objc dynamic var is_closed : Bool = false
    @objc dynamic var is_member : Bool = true
    @objc dynamic var membersCount : Int = 0
    @objc dynamic var name : String = ""
    @objc dynamic var photo : String = ""
    @objc dynamic var photo_big : String = ""
    @objc dynamic var photo_medium : String = ""
    @objc dynamic var screen_name : String = ""
    @objc dynamic var type : String = ""
    
   convenience init?(json: [String: Any]) {
    
        self.init()
    
        guard
        
        let id = json["gid"] as? Int,
        let is_admin = json["is_admin"] as? Bool,
        let is_closed = json["is_closed"] as? Bool,
        let is_member = json["is_member"] as? Bool,
        let membersCount = json["members_count"] as? Int,
        let name = json["name"] as? String,
        let photo = json["photo"] as? String,
        let photo_big = json["photo_big"] as? String,
        let photo_medium = json["photo_medium"] as? String,
        let screen_name = json["screen_name"] as? String,
        let type = json["type"] as? String
        
        else { return nil }
        
        self.id = id
        self.is_admin = is_admin
        self.is_closed = is_closed
        self.is_member = is_member
        self.membersCount = membersCount
        self.name = name
        self.photo = photo
        self.photo_big = photo_big
        self.photo_medium = photo_medium
        self.screen_name = screen_name
        self.type = type
        
    }
    
    static func getArray(from jsonDict: Any) -> [Group]? {
        
        guard let jsonDict = jsonDict as? [String:Any]
            else { return nil }
        guard let jsonArray = jsonDict["response"] as? [Any]
            else { return nil }
        
        var jsonFilteredArray = jsonArray
        _ = [jsonFilteredArray.remove(at: 0)]
        
        guard let jsonDictArray = jsonFilteredArray as? Array<[String: Any]>
            else { return nil }
        
        var groups: [Group] = []
        
        for jsonDictObject in jsonDictArray {
            if let group = Group(json: jsonDictObject) {
                groups.append(group)
            }
        }
        return groups
    }
}
