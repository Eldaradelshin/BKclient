//
//  GroupRequestService.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 31.01.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import Foundation
import Alamofire
import Realm
import RealmSwift

class GroupRequestService {
    

    
    fileprivate let baseUrl = "https://api.vk.com"
    fileprivate let client_id = "6197760"
    fileprivate let path = "/method/groups.get"
    fileprivate let version = "5.8"
    
    private var timer: Timer?
    
    func startFetchingGroups() {
        timer = Timer.scheduledTimer(timeInterval: 1800, target: self, selector: #selector(downloadGroupsData), userInfo: nil, repeats: true)
        timer!.fire()
    }
    
    func stopFetchingGroups() {
        timer?.invalidate()
    }

    func saveGroupData(_ groups:[Group]){
        do {
            let realm = try Realm()
            let oldGroups = realm.objects(Group.self)
            realm.beginWrite()
            realm.delete(oldGroups)
            realm.add(groups)
            try realm.commitWrite()
        } catch {
            print(error)
        }
    }
    
    
    @objc func downloadGroupsData() {
        
        let parameters:  Parameters = [  "access_token" : UserRequestService.token,
                                         "user_id"      : UserRequestService.userId,
                                         "extended"     : "1",
                                         "count"        : "50",
                                         "fields"       : "members_count",
                                         "version"      : version,                     ]
        
        let url = baseUrl + path
        
        request(url, method: .get, parameters: parameters).responseJSON { responseJSON in
            
            switch responseJSON.result {
            case .success(let value):
                //print(value)

                
                guard let groups = Group.getArray(from: value) else { return (print("Error in groups function"))}
                //print(groups)
                self.saveGroupData(groups)
                
                
            case .failure(let error):
                print("ERROR_IN_DOWNLOADING", error)
            
            }
        }
    }
}

