//
//  UsersTableViewController.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 07.01.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import UIKit
import Realm
import RealmSwift




class UsersTableViewController: UITableViewController {

    let userRequestService = UserRequestService()
    var users:Results<User>!
    //var users = [User]()
    var token = RLMNotificationToken()
    
    
    
    func loadUserData() {
        do {
            let realm = try Realm()
            users = realm.objects(User.self)
            token = users.observe { [weak self] changes in
                guard let tableView = self?.tableView else { return }
                switch changes {
                case .initial:
                    tableView.reloadData()
                    break
                case .update(_,let deletions, let insertions, let modifications):
                    tableView.beginUpdates()
                    tableView.insertRows(at: insertions.map({ IndexPath(row: $0, section: 0) }), with: .automatic)
                    tableView.deleteRows(at: deletions.map({ IndexPath(row: $0, section: 0) }), with: .automatic)
                    tableView.reloadRows(at: modifications.map({ IndexPath(row: $0, section: 0) }), with: .automatic)
                    tableView.endUpdates()
                    break
                case .error(let error):
                    fatalError("\(error)")
                }
            }
           
        } catch {
            print(error)
        }
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //userRequestService.downloadUsersData()
        userRequestService.startFetchingUsers()
        loadUserData()
        
    }
    
    
    deinit {
        userRequestService.stopFetchingUsers()
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
        return users.count
    }

  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "friendCell", for: indexPath) as! UsersTableViewCell
        
        cell.userId.text = "\(users[indexPath.row].userId)"
        cell.userName.text = users[indexPath.row].firstName + " " + users[indexPath.row].lastName
        cell.idUser = users[indexPath.row].userId
        let urlImg: URL = URL(string: users[indexPath.row].userPhoto)!
        let queue = DispatchQueue.global(qos: .utility)
        queue.async {
            if let dataImg = try? Data(contentsOf: urlImg) {
             DispatchQueue.main.async {
               cell.userAvatar.image = UIImage(data: dataImg)
                }
            }
        }
    
        return cell
    }
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "showPhoto" {
            let cell = sender as! UsersTableViewCell
            let selectedUser = users.filter({ $0.userId == cell.idUser})
            
            if selectedUser.count == 0 {
                fatalError()
            }
            
            
            let userFotoViewController = segue.destination as! UserFotoViewController
            userFotoViewController.firstName = selectedUser[0].firstName
            userFotoViewController.lastName = selectedUser[0].lastName
            userFotoViewController.bigPhotoURL = selectedUser[0].bigUserPhoto
        }
    
    }
    
    

}
