//
//  User.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 07.01.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import Foundation
import RealmSwift

class User: Object {
    
    
   @objc dynamic var lastName: String = ""
   @objc dynamic var userId: Int = 0
   @objc dynamic var firstName: String = ""
   @objc dynamic var userPhoto: String = ""
   @objc dynamic var uid: Int = 0
   @objc dynamic var bigUserPhoto: String = ""
    
   convenience init?(json: [String: Any]) {
    
        self.init()
        
        guard
        
            let lastName = json["last_name"] as? String,
            let userId = json["user_id"] as? Int,
            let firstName = json["first_name"] as? String,
            let userPhoto = json["photo_50"] as? String,
            let uid = json["uid"] as? Int,
            let bigUserPhoto = json["photo_100"] as? String
            
            else { return nil }
        
        
        self.lastName = lastName
        self.userId = userId
        self.firstName = firstName
        self.userPhoto = userPhoto
        self.uid = uid
        self.bigUserPhoto = bigUserPhoto
    }
    
    static func getArray(from jsonDict: Any) -> [User]? {
        
        guard let jsonDict = jsonDict as? [String:Any]
            else { return nil }
        guard   let jsonDictArray = jsonDict["response"] as? Array<[String:Any]>
            else { return nil }
        var users: [User] = []
        
        for jsonDictObject in jsonDictArray {
            if let user = User(json: jsonDictObject) {
                users.append(user)
            }
        }
        return users
    }
}
