//
//  UserRequestService.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 07.01.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import Foundation
import Alamofire
import Realm
import RealmSwift

class UserRequestService {
    
    
    static var token = ""
    static var userId = 0
    
    fileprivate let baseUrl = "https://api.vk.com"
    fileprivate let client_id = "6197760"
    fileprivate let path = "/method/friends.get"
    fileprivate let version = "5.8"
    
    private var timer: Timer?
    
    func startFetchingUsers() {
        timer = Timer.scheduledTimer(timeInterval: 1800, target: self, selector: #selector(downloadUsersData), userInfo: nil, repeats: true)
        timer!.fire()
    }
    
    func stopFetchingUsers() {
        timer?.invalidate()
    }
    
    
    func saveUserData(_ users:[User]){
        do {
            let realm = try Realm()
            //print(realm.configuration.fileURL)
            let oldUsers = realm.objects(User.self)
            
            realm.beginWrite()
            
            realm.delete(oldUsers)
            
            realm.add(users)
            try realm.commitWrite()
        } catch {
            print(error)
        }
    }
    
    
    
    @objc func downloadUsersData() {
        
        let parameters: Parameters = [ "user_id"   :  UserRequestService.userId,
                                       "order"     :  "name",
                                       "count"     :  "50",
                                       "fields"    :  "nickname, photo_50, photo_100",
                                       "version"   :  version,
                                       "name_case" :  "nom",
                                                                                  ]
        
        let url = baseUrl + path
        
        
        request(url, method: .get, parameters: parameters).responseJSON { responseJSON in
            
            switch responseJSON.result {
            case .success(let value):
        
                guard let users = User.getArray(from: value) else { return (print("Error in function"))}
               // print(users)
               //print("data fetched")
                self.saveUserData(users)
                
            case .failure(let error):
                print("ERROR_IN_DOWNLOADING", error)
            
               
            }
    }
    
    
}
}
    
    
    
    
    
    
    
    
    
    

