//
//  UserFotoViewController.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 29.01.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

class UserFotoViewController: UICollectionViewController {
    
    let userRequestService = UserRequestService()
    
    var firstName   = ""
    var lastName    = ""
    var bigPhotoURL = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = firstName + " " + lastName
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return 1
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "userFotoCell", for: indexPath) as! UsersFotoCell
    
        let urlBigImg: URL = URL(string: bigPhotoURL)!
        let queue = DispatchQueue.global(qos: .utility)
        queue.async {
            if let dataBigImg = try? Data(contentsOf: urlBigImg) {
                DispatchQueue.main.async {
                    cell.userFoto.image = UIImage(data: dataBigImg)
                    
                }
            }
        }
        
        return cell
    }

}
