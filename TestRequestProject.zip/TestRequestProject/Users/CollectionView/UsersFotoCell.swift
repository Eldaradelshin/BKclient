//
//  UsersFotoCell.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 29.01.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import UIKit

class UsersFotoCell: UICollectionViewCell {
    
    @IBOutlet weak var userFoto: UIImageView!
}
