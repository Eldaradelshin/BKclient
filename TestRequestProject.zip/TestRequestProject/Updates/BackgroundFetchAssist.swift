//
//  BackgroundFetchAssist.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 13.04.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import Foundation


class BackgroundFetchAssist {
    let fetchCitiesWeatherGroup = DispatchGroup()
    var timer: DispatchSourceTimer?
    
    static let instance = BackgroundFetchAssist()
    private init(){}
    
    var lastUpdate: Date? {
        get {
            return UserDefaults.standard.object(forKey: "Last Update") as? Date
        }
        set {
            UserDefaults.standard.setValue(Date(), forKey: "Last Update")
        }
    }
}
