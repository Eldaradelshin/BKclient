//
//  GroupsSearchTableViewController.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 03.04.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import UIKit

class GroupsSearchTableViewController: UITableViewController, UISearchBarDelegate {
    
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    let groupSearchRequestService = GroupSearchRequestService()
      var searchedGroups = [SearchedGroup]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setUpSearchBar()
        
        /*
        groupSearchRequestService.downloadGroupsSearchData(searchedString: "lenta"){ [weak self] searchedGroups in
            self?.searchedGroups = searchedGroups
            self?.tableView?.reloadData()
        } */
    }
    
    private func setUpSearchBar() {
        searchBar.delegate = self
    }


    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchedGroups.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "searchGroupCell", for: indexPath) as! GroupSearchTableViewCell
        cell.groupName.text = searchedGroups[indexPath.row].name
        let urlImg: URL = URL(string: searchedGroups[indexPath.row].photo)!
        let queue = DispatchQueue.global(qos: .utility)
        queue.async {
            if let dataImg = try? Data(contentsOf: urlImg) {
                DispatchQueue.main.async {
                    cell.groupAvatar.image = UIImage(data: dataImg)
                    
                }
            }
        }

        return cell
    }
 
   //SearchBar
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else {
            tableView.reloadData()
            return
        }
        groupSearchRequestService.downloadGroupsSearchData(searchedString: searchText.lowercased()){ [weak self] searchedGroups in
            self?.searchedGroups = searchedGroups
            self?.tableView?.reloadData()
        }
}
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        self.searchBar.showsCancelButton = true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.showsCancelButton = false
        searchBar.text = ""
        searchBar.resignFirstResponder()
        searchedGroups = []
        tableView?.reloadData()
    }
}
