//
//  SearchedGroup.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 03.04.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import Foundation

class SearchedGroup {
    
var is_admin : Bool
var photo_medium : String
var name : String
var screen_name : String
var photo : String
var id : Int
var photo_big : String
var type : String
var is_closed : Bool
var is_member : Bool
    

init?(json: [String: Any]) {
    
    guard
    
        let is_admin = json["is_admin"] as? Bool,
        let photo_medium = json["photo_medium"] as? String,
        let name = json["name"] as? String,
        let screen_name = json["screen_name"] as? String,
        let photo = json["photo"] as? String,
        let id = json["gid"] as? Int,
        let photo_big = json["photo_big"] as? String,
        let type = json["type"] as? String,
        let is_closed = json["is_closed"] as? Bool,
        let is_member = json["is_member"] as? Bool
    
        else { return nil }
    
    self.id = id
    self.is_admin = is_admin
    self.is_closed = is_closed
    self.is_member = is_member
    self.name = name
    self.photo = photo
    self.photo_big = photo_big
    self.photo_medium = photo_medium
    self.screen_name = screen_name
    self.type = type
    
}

static func getArray(from jsonDict: Any) -> [SearchedGroup]? {
    
    guard let jsonDict = jsonDict as? [String:Any]
        else { return nil }
    guard let jsonArray = jsonDict["response"] as? [Any]
        else { return nil }
    
    var jsonFilteredArray = jsonArray
    _ = [jsonFilteredArray.remove(at: 0)]
    
    guard let jsonDictArray = jsonFilteredArray as? Array<[String: Any]>
        else { return nil }
    
    var searchedGroups: [SearchedGroup] = []
    
    for jsonDictObject in jsonDictArray {
        if let searchedGroup = SearchedGroup(json: jsonDictObject) {
            searchedGroups.append(searchedGroup)
        }
    }
    return searchedGroups
}
}
