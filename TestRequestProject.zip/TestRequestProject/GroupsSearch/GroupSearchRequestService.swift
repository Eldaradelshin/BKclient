//
//  GroupSearchRequestService.swift
//  TestRequestProject
//
//  Created by rushan adelshin on 03.04.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

import Foundation
import Alamofire

class GroupSearchRequestService {
    
    fileprivate let baseUrl = "https://api.vk.com"
    fileprivate let client_id = "6197760"
    fileprivate let path = "/method/groups.search"
    fileprivate let version = "5.8"
    
    
    
    func downloadGroupsSearchData(searchedString: String,completion: @escaping ([SearchedGroup]) -> Void) {
        
        let parameters: Parameters = [ "q"      : searchedString,
                                       "access_token" : UserRequestService.token,
                                       "type"   : "",
                                       "sort"   : "",
                                       "offset" : "0",
                                       "count"  : "30",
                                       "version": version,                                   ]
        
        let url = baseUrl + path
        
        request(url, method: .get, parameters: parameters).responseJSON { responseJSON in
            
            switch responseJSON.result {
            case.success(let value):
                //print(value)
                
                guard let searchedGroups = SearchedGroup.getArray(from: value)  else { return (print("Error in groups function"))}
                //print(searchedGroups)
                completion(searchedGroups)
                
                
            case.failure(let error):
                print("ERROR_IN_DOWNLOADING", error)
            }
            
        }
        
    }
}
